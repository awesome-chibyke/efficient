(function ($) {
    "use strict";

    $('#summernote').summernote({
        placeholder: 'Enter News Here!',
        tabsize: 1,
        height: 300
    });

    $('#summernote2').summernote({
        placeholder: 'Enter News Here!',
        tabsize: 1,
        height: 600
    });

})(jQuery);